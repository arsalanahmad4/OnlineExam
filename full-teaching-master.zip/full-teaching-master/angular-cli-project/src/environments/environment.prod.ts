export const environment = {
  production: true,
  URL_UPLOAD: 'https://34.253.22.61:5000/api-load-files/upload/course/',
  URL_PIC_UPLOAD: 'https://34.253.22.61:5000/api-load-files/upload/picture/',
  URL_EMAIL_FILE_UPLOAD: 'https://34.253.22.61:5000/api-file-reader/upload/course/',
  PUBLIC_RECAPTCHA_KEY: '6LeYuxIUAAAAAJ38G5U4sYYI0SLZ5JOYRJWrViLe',
  OPENVIDU_URL:'wss://34.253.22.61:8443/',
  CHAT_URL: 'wss://34.253.22.61:5000/chat'
};
