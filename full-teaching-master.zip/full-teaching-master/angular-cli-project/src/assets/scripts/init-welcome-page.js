// $(document).ready(function(){
//   $('.modal-trigger').modal({
//     ready: function() { alert('Ready'); },
//   }); // the "href" attribute of .modal-trigger must specify the modal ID that wants to be triggered
// });
